Instructions:
1. start "install.cmd"

What does the installation files?:
The install.cmd will unblock and start the install.ps1 script. (-ExecutionPolicy Bypass)
The install.ps1 will download the latest version of Customballer Gunsmith from GitHub and past it in your current Customballer Gunsmith root folder.


Donation:
All my mods are free. If you'd like to support me, feel free to send me a voluntary donation here: https://buymeacoffee.com/nomaeck.
If you don't want to support me financially, I would also appreciate an "endorse" on Nexusmods!
Thank you for your support :)