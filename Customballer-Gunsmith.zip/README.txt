Instructions:
1. start "Run-Customballer-Gunsmith.bat"
2. Select a pistol you want to replace with your own Customballer Mod
3. Enter a new name for this weapon
4. Choose your own Gunparts combination
5. When you have selected everything, press the "Generate Mod" Button
6. Start Simple Mod Framework and press "Add a Mod"
7. Import your own Customballer Mod: "Customballer_Gunsmith\Customballer-Mods\"Your Gun Name.zip""
8. Press "Apply"
9. Enjoy
10. Please post your own Customballer screenshots on my mod page. I want to see your creativity!

Optional:
If you want to change the Mission Planning Item Picture from your gun:
1. Open the Folder "Simple Mod Framework\Mods\"Your Customballer Name_CBG_NOMAECK"\blobs\images\unlockables_override\
2. Replace the picture "customballer.jpg" with a jpg screenshot of your gun, but keep the name "customballer.jpg" and the size of 696x520 pixels.

Informations:
The Customballer Gunsmith will not change the Damage of the gun you replace.
All you guns will have the "steady aim" perk.
Categories that are not compatible with your selected gunparts will be automatically deactivated in Gunsmith.
If you choose a suppressor the sound will be automatically suppressed. But if you don´t choose a suppressor you can also select a suppressed sound for you gun.
Feel free to upload your own Customballer Mod generated with my Customballer Gunsmith only on Nexusmods but please add me as second mod author. Thanks :)
You are not allowed to modify and publish the Customballer Gunsmith.


What does the Customballer Gunsmith?:
This Powersehll GUI Tool just generating json modfiles for you and zip it into a real mod.
So you only need to import your self generated customballer mod with simple mod framework.

Donation:
All my mods are free. If you'd like to support me, feel free to send me a voluntary donation here: https://buymeacoffee.com/nomaeck.
If you don't want to support me financially, I would also appreciate an "endorse" on Nexusmods!
Thank you for your support :)


Version:
1.1